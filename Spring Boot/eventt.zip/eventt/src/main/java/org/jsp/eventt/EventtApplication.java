package org.jsp.eventt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventtApplication.class, args);
	}

}
