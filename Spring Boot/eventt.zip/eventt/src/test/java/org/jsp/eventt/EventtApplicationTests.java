package org.jsp.eventt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventtApplicationTests {

	@Test
	void contextLoads() {
	}

}
