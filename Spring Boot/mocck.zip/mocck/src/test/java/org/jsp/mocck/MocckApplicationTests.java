package org.jsp.mocck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MocckApplicationTests {

	@Test
	void contextLoads() {
	}

}
