package org.jsp.mocck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MocckApplication {

	public static void main(String[] args) {
		SpringApplication.run(MocckApplication.class, args);
	}

}
